MAS GON CRUELL — WEBSITE FINAL
Siap upload ke GitHub Pages.

Struktur:
- index.html
- style.css
- script.js
- .nojekyll
- assets/banner-masgon.jpg
- assets/logo-masgon.jpg

WhatsApp:
- Joki: 0858-6322-1803
- Stock: 0831-8278-4205
- JP: 0831-8278-4382
- Produk Digital: 0831-8278-4382

Pesan otomatis:
- Joki: Halo Masgoncruell, Saya ingin memesan layanan : joki game
- Stock: Halo mas gon cruell, saya ingin membeli akun ff
- JP: Halo mas gon cruell, saya ingin jasa post akun saya
- Produk Digital: Halo mas gon cruell, saya ingin membeli produk digital

UPLOAD KE GITHUB PAGES:
1. Buat repository baru di GitHub.
2. Upload semua isi folder ini (bukan ZIP-nya).
3. Pastikan index.html berada langsung di root repository.
4. Settings > Pages.
5. Build and deployment > Deploy from a branch.
6. Branch: main, folder: / (root), lalu Save.
7. Tunggu beberapa menit sampai link Pages aktif.

Website ini statis dan tombol pemesanan langsung membuka WhatsApp.
